﻿namespace TH_W3
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.openNextFormButton = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.nameTextBox = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.artistTextBox = new System.Windows.Forms.TextBox();
            this.allContentCheckBox = new System.Windows.Forms.CheckBox();
            this.submitButton = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // openNextFormButton
            // 
            this.openNextFormButton.Location = new System.Drawing.Point(407, 14);
            this.openNextFormButton.Margin = new System.Windows.Forms.Padding(2);
            this.openNextFormButton.Name = "openNextFormButton";
            this.openNextFormButton.Size = new System.Drawing.Size(102, 36);
            this.openNextFormButton.TabIndex = 0;
            this.openNextFormButton.Text = "Open Next Form";
            this.openNextFormButton.UseVisualStyleBackColor = true;
            this.openNextFormButton.Click += new System.EventHandler(this.openNextFormButton_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label1.Location = new System.Drawing.Point(34, 79);
            this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(35, 13);
            this.label1.TabIndex = 1;
            this.label1.Text = "Name";
            // 
            // nameTextBox
            // 
            this.nameTextBox.Location = new System.Drawing.Point(150, 77);
            this.nameTextBox.Margin = new System.Windows.Forms.Padding(2);
            this.nameTextBox.Name = "nameTextBox";
            this.nameTextBox.Size = new System.Drawing.Size(197, 20);
            this.nameTextBox.TabIndex = 2;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(34, 127);
            this.label2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(88, 13);
            this.label2.TabIndex = 3;
            this.label2.Text = "My Favorite Artist";
            // 
            // artistTextBox
            // 
            this.artistTextBox.Location = new System.Drawing.Point(150, 123);
            this.artistTextBox.Margin = new System.Windows.Forms.Padding(2);
            this.artistTextBox.Name = "artistTextBox";
            this.artistTextBox.Size = new System.Drawing.Size(197, 20);
            this.artistTextBox.TabIndex = 5;
            // 
            // allContentCheckBox
            // 
            this.allContentCheckBox.AutoSize = true;
            this.allContentCheckBox.Location = new System.Drawing.Point(150, 156);
            this.allContentCheckBox.Margin = new System.Windows.Forms.Padding(2);
            this.allContentCheckBox.Name = "allContentCheckBox";
            this.allContentCheckBox.Size = new System.Drawing.Size(196, 17);
            this.allContentCheckBox.TabIndex = 6;
            this.allContentCheckBox.Text = "All of the content i put above is true!";
            this.allContentCheckBox.UseVisualStyleBackColor = true;
            this.allContentCheckBox.CheckedChanged += new System.EventHandler(this.allContentCheckBox_CheckedChanged);
            // 
            // submitButton
            // 
            this.submitButton.Enabled = false;
            this.submitButton.Location = new System.Drawing.Point(213, 193);
            this.submitButton.Margin = new System.Windows.Forms.Padding(2);
            this.submitButton.Name = "submitButton";
            this.submitButton.Size = new System.Drawing.Size(61, 27);
            this.submitButton.TabIndex = 7;
            this.submitButton.Text = "Submit";
            this.submitButton.UseVisualStyleBackColor = true;
            this.submitButton.Click += new System.EventHandler(this.submitButton_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(533, 292);
            this.Controls.Add(this.submitButton);
            this.Controls.Add(this.allContentCheckBox);
            this.Controls.Add(this.artistTextBox);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.nameTextBox);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.openNextFormButton);
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "Form1";
            this.Text = "Main Window Form";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button openNextFormButton;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox nameTextBox;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox artistTextBox;
        private System.Windows.Forms.CheckBox allContentCheckBox;
        private System.Windows.Forms.Button submitButton;
    }
}

