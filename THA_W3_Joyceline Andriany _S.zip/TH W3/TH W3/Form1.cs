﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TH_W3
{
    public partial class Form1 : Form
    {
        Form2 secondForm;
        string name, artist;
        Color bgColor, textColor;
        

        public Form1()
        {
            InitializeComponent();
        }

        public void secondFormClosed() {
            secondForm = null;
        }

        private void openNextFormButton_Click(object sender, EventArgs e)
        {
            secondForm = new Form2(this);
            secondForm.Show();
            submitButtonEnabler();
        }
        private void submitButton_Click(object sender, EventArgs e)
        {
            
            name = nameTextBox.Text;
            artist = artistTextBox.Text;
            if (name== "" || artist == "")
            {
                MessageBox.Show("Name and Artist not valid!");
                return;
            }

            secondForm.setHelloLabelText(name, artist);          
        }

        private void allContentCheckBox_CheckedChanged(object sender, EventArgs e)
        {
            submitButtonEnabler();
        }
        public void submitButtonEnabler() {
            if (secondForm == null)
            {
                submitButton.Enabled = false;
                return;
            }
            submitButton.Enabled = allContentCheckBox.Checked && secondForm.Visible;
        }



        public void SetColors(Color background, Color text)
        {
            bgColor = background;
            textColor = text;
            BackColor = bgColor;
            //nameTextBox.BackColor = bgColor;
            //artistTextBox.BackColor = bgColor;
            nameTextBox.ForeColor = textColor;
            artistTextBox.ForeColor = textColor;
            label1.ForeColor = textColor;
            label2.ForeColor = textColor;
            allContentCheckBox.ForeColor = textColor;
            submitButton.ForeColor = textColor;
            openNextFormButton.ForeColor = textColor;
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            bgColor = BackColor;
            textColor = Color.Black;
        }
    }
}







