﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net.Configuration;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml;

namespace TH_W3
{
    public partial class Form2 : Form
    {
        Form1 firstForm;
        Color bg_color, text_color;
        bool isAgreeChecked, isAllChecked;

        public Form2(Form1 f)
        {
            InitializeComponent();
            firstForm = f;
        }

        public void setHelloLabelText(string name, string favArtist) {
            helloLabel.Text = "Hi, my name is "+name+" and my favorite artist is "+ favArtist;
        }
        private void magicButton_Click(object sender, EventArgs e)
        {
            if (bg_color == null || text_color == null)
            {
                MessageBox.Show("You need to pick the Background and Text color first");
            }
            firstForm.SetColors(bg_color, text_color);
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void Form2_Load(object sender, EventArgs e)
        {
            magictBtnEnabler();
            colorRadioButton.Checked = true;
            textColorRadioButton.Checked = true;
        }

        private void Form2_FormClosed(object sender, FormClosedEventArgs e)
        {
            firstForm.secondFormClosed();
            firstForm.submitButtonEnabler();
        }

        private void AgreeChecked_CheckedChanged(object sender, EventArgs e)
        {
            magictBtnEnabler();
        }

        private void AllChecked_CheckedChanged(object sender, EventArgs e)
        {
            magictBtnEnabler();
        }
        private void magictBtnEnabler() {
            magicButton.Enabled = AgreeChecked.Checked && AllChecked.Checked;
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void textColorRadioButton_CheckedChanged(object sender, EventArgs e)
        {

            RadioButton radioButton = sender as RadioButton;

            if (!radioButton.Checked) return;

            switch (radioButton.Text.ToLower())
            {
                case "blue":
                    text_color = Color.Blue;
                    break;
                case "red":
                    text_color = Color.Red;
                    break;
                case "black":
                    text_color = Color.Black;
                    break;
            }
        }

        private void colorRadioButton_CheckedChanged(object sender, EventArgs e)
        {
            RadioButton radioButton = sender as RadioButton;

            if (!radioButton.Checked) return;
            
            switch (radioButton.Text.ToLower())
            {
                case "blue":
                    bg_color = Color.Blue;
                    break;
                case "purple":
                    bg_color = Color.Purple;
                    break;
                case "red":
                    bg_color = Color.Red;
                    break;
                case "green":
                    bg_color = Color.Green;
                    break;
                case "black":
                    bg_color = Color.Black;
                    break;
            }
        }

        private void text_colorRadioButton_CheckedChanged(object sender, EventArgs e)
        {
            RadioButton radioButton = sender as RadioButton;
            if (radioButton.Checked)
            {
                switch (radioButton.Text.ToLower())
                {
                    case "Blue":
                        text_color = Color.Blue;
                        break;
                    case "Black":
                        text_color = Color.Black;
                        break;
                    case "Red":
                        text_color = Color.Red;
                        break;
                }
                firstForm.SetColors(bg_color, text_color);
            }
        }
        //public void SetLabelText(string name, string artist)
        //{
        //    //nameLabel.Text = "Hi, my name is " + name + " and my favorite artist is " + artist;

        //}
        }
    }

